package com.cwc.vplayer.entity

data class VideoFile(

    //数据字段
    val title: String = "",
    val size: Long = 0,
    val path: String = "",
    val lastModify: String = ""


    //  功能字段

)