package com.shuyu.gsyvideoplayer.player;


import com.cwc.vplayer.base.model.VideoModel;
import com.cwc.vplayer.base.player.IPlayerInitSuccessListener;
import com.cwc.vplayer.base.player.IPlayerManager;

/**
 * 播放器差异管理接口
 */

public abstract class BasePlayerManager implements IPlayerManager {

    protected IPlayerInitSuccessListener mPlayerInitSuccessListener;

    public IPlayerInitSuccessListener getPlayerPreparedSuccessListener() {
        return mPlayerInitSuccessListener;
    }

    public void setPlayerInitSuccessListener(IPlayerInitSuccessListener listener) {
        this.mPlayerInitSuccessListener = listener;
    }

    protected void initSuccess(VideoModel videoModel) {
        if (mPlayerInitSuccessListener != null) {
            mPlayerInitSuccessListener.onPlayerInitSuccess(getMediaPlayer(), videoModel);
        }
    }
}
